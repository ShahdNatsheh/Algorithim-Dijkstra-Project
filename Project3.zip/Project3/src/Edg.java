

public class Edg {
	private Vertex source;
	private Vertex target;
	private Vertex destination;
	private double cost;
	private double x;
	private double y;
	private double c;
	
	
	
	public Edg(Vertex source, Vertex destination, double cost) {
		super();
		this.source = source;
		this.destination = destination;
		this.cost = cost;
	}
	
	
	public Edg(Vertex destination, double cost) {
		super();
		this.destination = destination;
		this.cost = cost;
	}
	public Edg(double x, double y,double c) {
		super();
		this.x=source.getX();
		this.y=target.getY();
		this.cost=c;
	}
	


	public Vertex getSource() {
		return source;
	}
	public void setSource(Vertex source) {
		this.source = source;
	}
	public Vertex getDestination() {
		return destination;
	}
	public void setDestination(Vertex destination) {
		this.destination = destination;
	}
	public double getCost() {
		return cost;
	}
	public void setCost(double cost) {
		this.cost = cost;
	}


	@Override
	public String toString() {
		return "Edge [source=" + source + ", destination=" + destination + ", cost=" + cost + "]";
	}
	
	
	
}
