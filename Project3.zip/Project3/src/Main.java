

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.RenderingHints;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Scanner;

import javax.swing.JPanel;

import javafx.application.Application;
import javafx.beans.value.ChangeListener;
import javafx.event.EventHandler;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.stage.Stage;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.Border;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.BorderStroke;
import javafx.scene.layout.BorderStrokeStyle;
import javafx.scene.layout.BorderWidths;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Line;
import javafx.scene.shape.Polyline;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;

public class Main extends Application {

	static int count =0;
	static Group groupCFE = new Group();

	static ComboBox cboxSource = new ComboBox();
	static ComboBox cboxTarget = new ComboBox();

	Button run = new Button("Run");
	Label path = new Label ();
	Label dist= new Label ();

	static ArrayList <Vertex> list = new ArrayList <Vertex>();
	static LinkedList<Edg> l=new LinkedList<Edg>();
	static HashMap <Vertex,LinkedList<Edg>> edges = new HashMap<>();
	static BorderPane root = new BorderPane();
	static Pane  pane = new Pane();
	static Line line = new Line();
	static Group group = new Group();
	static Circle c ;

	@Override
	public void start(Stage primaryStage) {
		try {
			root.setRight(box());
			root.setPadding(new Insets(100,100,100,100));
			Image img = new Image("map2.png");
			ImageView imgView = new ImageView(img);
			pane.getChildren().add(imgView);
			root.setCenter(pane);


			readxy();
		//readEdg();

			cboxSource.setPromptText("Source");
			cboxTarget.setPromptText("Target");
			for(int i=0;i<list.size();i++)
			{	cboxSource.getItems().add(list.get(i).getName());
			cboxTarget.getItems().add(list.get(i).getName());
			}
			

			pane.getChildren().add(groupCFE);

			run.setOnAction(e->{
		      readEdg();
				groupCFE.getChildren().clear();
				pane.getChildren().remove(groupCFE);
				Dijkstra_ d = new Dijkstra_(edges,list);
				
				if (cboxSource.getSelectionModel().getSelectedIndex()==cboxTarget.getSelectionModel().getSelectedIndex())
					
				{
					
					
					path.setText(cboxSource.getValue()+"");
				dist.setText("");
				return;
				}
				d.execute(list.get(cboxSource.getSelectionModel().getSelectedIndex()), list.get(cboxTarget.getSelectionModel().getSelectedIndex()));
				LinkedList <Vertex> l = d.getPath(list.get(cboxTarget.getSelectionModel().getSelectedIndex()), list.get(cboxSource.getSelectionModel().getSelectedIndex()));
				if (l==null)
				{	path.setText("no path");
				return;
				}

				else
				{
					String pathS = l.get(0).getName()+"-->"+"\n";;
					for (int i=1;i<l.size();i++)
					pathS+=l.get(i).getName()+"-->"+"\n";
				
					path.setText(pathS);
				}
				dist.setText(d.getPathD()+"");
				for (int i=0;i<l.size()-1;i++)
					groupCFE.getChildren().add( new Line( l.get(i).getX() ,l.get(i).getY(), l.get(i+1).getX(), l.get(i+1).getY()));
				pane.getChildren().add(groupCFE);
			});


			for (int i=0;i<list.size();i++)
			{
				cboxSource.setId(list.get(i).getName());
			
				cboxTarget.setId(list.get(i).getName());

			}

			Scene scene = new Scene(root,1000,1000);
			scene.getStylesheets().add(getClass().getResource("application.css").toExternalForm());
			primaryStage.setScene(scene);
			primaryStage.show();

		} catch(Exception e) {
			e.printStackTrace();
		}
	}

	VBox box ()
	{  run.setMinSize(60, 30);
	run.setFont(Font.font("verdana", FontWeight.SEMI_BOLD, FontPosture.REGULAR, 18));
	cboxSource.setMinSize(150,30);
	cboxTarget.setMinSize(150,30);


	Label l =new Label ("Source ");
	Label l2=new Label ("Target ");
	Label l3=new Label ("Path");
	Label l4=new Label ("Shortest Distence");

	l.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 18)); 
	l2.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 18)); 
	l3.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 18)); 
	l4.setFont(Font.font("verdana", FontWeight.BOLD, FontPosture.REGULAR, 18)); 
	path.setFont(Font.font("verdana", FontWeight.NORMAL, FontPosture.REGULAR, 18));
	dist.setFont(Font.font("verdana", FontWeight.NORMAL, FontPosture.REGULAR, 18));

	path.setStyle("-fx-border-color: Black ");
	VBox vbox = new VBox ();
	vbox.setSpacing(20);
	HBox hb1 = new HBox();
	HBox hb2 = new HBox();
	HBox hb3 = new HBox();
	HBox hb4 = new HBox();
    HBox hb5=new HBox();
	hb1.getChildren().addAll(l,cboxSource);
	hb2.getChildren().addAll(l2,cboxTarget);
	hb3.getChildren().addAll(l3,path);
	hb4.getChildren().addAll(l4,dist);
	hb5.getChildren().addAll(hb1,hb2);
	vbox.getChildren().addAll(hb5,run,hb3,hb4);
    vbox.setSpacing(30);
	hb5.setSpacing(20);
	hb3.setSpacing(20);
	hb4.setSpacing(20);

	return vbox;

	}

	static void readxy()
	{	
		int i=0;

		String content=new String();
		try {
			File file=new File("xy.txt");
			Scanner scan=new Scanner(file);
			while(scan.hasNextLine()) {
				 Text text = new Text();

				content=scan.nextLine();
				
				String [] array=content.trim().split("\\s+");
				
				
				
				list.add(new Vertex (i++,array[0],Double.parseDouble(array[1]),Double.parseDouble(array[2])));

				pane.getChildren().add(list.get(list.size()-1).getCircle());

				edges.put(list.get(list.size()-1), new LinkedList <Edg>());
				 text.setText(array[0]);
		          text.setX(Double.parseDouble(array[1])/10);
		            text.setY(Double.parseDouble(array[2])/13);
				 

			}
			scan.close(); 
		}
		catch (Exception e) {
			System.out.println(e);
		}


	}
	static void readEdg()
	{	


		String content=new String();
		try {
			File file=new File("cost.txt");
			Scanner scan=new Scanner(file);
			while(scan.hasNextLine()) {
				content=scan.nextLine();
				
				String [] array=content.trim().split("\\s+");
			
				// get liked list for the key
				Vertex v = getVertex(array[1]);
				Vertex v2 = getVertex(array[0]);
				LinkedList<Edg> l= edges.get(v);
				LinkedList<Edg> l2= edges.get(v2);
				
			double cost=Math.sqrt( Math.pow(getVertex(array[0]).getX()-getVertex(array[1]).getX(),2) +  Math.pow(getVertex(array[1]).getY()-getVertex(array[0]).getY(),2));
			l.add(new Edg (getVertex(array[0]),cost));
			l2.add(new Edg (getVertex(array[1]),cost));
				

				
groupCFE.getChildren().add( new Line(v.getX(), v.getY(),   getVertex(array[1]).getX(),   getVertex(array[1]).getY()));
//System.out.println(l);

			}
			
			scan.close(); 

		}
		catch (Exception e) {
			System.out.println(e);
		}


	}
	static Vertex getVertex (String name )
	{
		for (int i=0;i<list.size();i++)
		{if (list.get(i).getName().equalsIgnoreCase(name))
			return list.get(i);
		}
		return null;
	}

	public static void main(String[] args) {
		launch(args);



	}



}
